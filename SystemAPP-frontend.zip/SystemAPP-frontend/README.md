# SystemAPP

SETUP 

cd dentista

npx expo start

(se der problema) usa ->

npm install yet

e logo npx expo start